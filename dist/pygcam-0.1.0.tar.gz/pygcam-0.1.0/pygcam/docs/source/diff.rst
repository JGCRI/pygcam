The ``pygcam.diff`` module
============================

Functions for computing differences between CSV files and generating CSV and XLSX files.

API
---

.. automodule:: pygcam.diff
   :members:

