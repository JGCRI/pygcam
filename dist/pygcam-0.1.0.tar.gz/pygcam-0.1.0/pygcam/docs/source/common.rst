The ``pygcam.common`` module
============================

This module contains constants, functions, and classes that are used by various
other modules of the pygcam toolkit.

API
---

.. automodule:: pygcam.common
   :members:
