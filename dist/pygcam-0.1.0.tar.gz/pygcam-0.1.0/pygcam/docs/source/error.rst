The ``pygcam.error`` module
============================

This module contains subclasses of Exception used by pygcam.

API
---

.. automodule:: pygcam.error
   :members:

