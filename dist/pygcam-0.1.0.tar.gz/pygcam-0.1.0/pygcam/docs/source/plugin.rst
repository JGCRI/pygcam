The ``pygcam.plugin`` module
============================

This module contains the Plugin abstract base class and the
PluginManager class.

API
---

.. automodule:: pygcam.plugin
   :members:

