``pygcam.project``
=============================

This module provides all the functionality that is exposed through the command-line
to the :ref:`gcamtool runProj <runProj-label>` sub-command. It is provided in library
form so that it can be used from within other programs without having to execute the script.

API
---

.. automodule:: pygcam.project
   :members:
